package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class viewappointments {
	public static void main(String args[])
	{
		viewappointments object=new viewappointments();
	object.appointmentlist();
	}
	public  List<appointmentbean> appointmentlist(){
		List<appointmentbean> list=new ArrayList<appointmentbean>();
	try
	{     
	      Connection con=DB.con(); 
			              
			PreparedStatement ps=con.prepareStatement(  
			    "select * from world.appointment "); 
			
			ResultSet rs=ps.executeQuery(); 
			
			 
			while (rs.next()) 
	             {   appointmentbean obj=new appointmentbean();
				     obj.setPatientname(rs.getString("patientname")); 
				     obj.setPatientemail(rs.getString("patientemail")); 
				     obj.setDoctorname(rs.getString("doctorname")); 
				     obj.setDoctoremail(rs.getString("doctoremail")); 
				     obj.setLocation(rs.getString("location")); 
	                 obj.setSpecialist(rs.getString("specialist"));  
	                 
	                 
	                 list.add(obj);
	                 
	                 
	             } 
			
	             con.close();
	}
	   catch (Exception e) 
	            {  
	             System.out.println("error");  
	         }
	return list;  

	             

}
}
