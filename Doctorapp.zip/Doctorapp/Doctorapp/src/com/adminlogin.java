package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class adminlogin {
	public static boolean validate(logincom com)
	{  
		boolean status=true;  
		try
		{  
		Connection con=DB.con(); 
		              
		PreparedStatement ps=con.prepareStatement(  
		    "select * from world.admin where email=? and psw=?");  
		  
		ps.setString(1,com.getemail());  
		ps.setString(2, com.getpsw());  
		              
		ResultSet rs=ps.executeQuery();  
		status=rs.next(); 
		System.out.println(status);
		              
		}
		catch(Exception e){}  
		  
		return status;  
		  
		}

}
