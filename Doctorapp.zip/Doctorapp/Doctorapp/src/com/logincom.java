package com;

public class logincom {
private String email,psw;  

public String getemail() {  
  return email;  
}  

public void setemail(String email) {  
  this.email = email;  
}  

public String getpsw() {  
  return psw;  
}  

public void setpsw(String psw) {  
  this.psw = psw;  
}  


}  



