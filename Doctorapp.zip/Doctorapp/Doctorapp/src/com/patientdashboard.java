package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class patientdashboard 
{   public static void main(String args[])
	{
	patientdashboard object=new patientdashboard();
	object.doctorslist();
	}
	public  List<Doctorbean> doctorslist(){
		List<Doctorbean> list=new ArrayList<Doctorbean>();
	try
	{     
	      Connection con=doctorloginDB.con(); 
			              
			PreparedStatement ps=con.prepareStatement(  
			    "select * from doctor "); 
			
			ResultSet rs=ps.executeQuery(); 
			
			 
			while (rs.next()) 
	             {   Doctorbean obj=new Doctorbean();
				     obj.setName(rs.getString("name")); 
	                 obj.setSpecialist(rs.getString("specialist"));  
	                 obj.setAvailability(rs.getString("availability"));  
	                 obj.setExperience(rs.getInt("experience"));   
	                 obj.setphone(rs.getString("phone"));
	                 
	                 list.add(obj);
	                 
	                 
	             } 
			
	             con.close();
	}
	   catch (Exception e) 
	            {  
	             System.out.println("error");  
	         }
	return list;  

	             
}}
