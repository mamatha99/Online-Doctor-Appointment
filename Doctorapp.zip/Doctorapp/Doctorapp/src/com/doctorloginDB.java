package com;

import java.sql.Connection;
import java.sql.DriverManager;

public class doctorloginDB {
	final static String DB_URL = "jdbc:mysql://127.0.0.1:3306/world";
	final static String USER = "root";
	final static String PASS = "Jaigurudev@1976";
	public static Connection con()
	{
		Connection con;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			return con;
			}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	
	

}
