package com;
 
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.DB; 
import java.sql.Connection;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class patientloginform {
	public static boolean validate(logincom com)
	{  
		boolean status=true;  
		try
		{  
		Connection con=DB.con(); 
		              
		PreparedStatement ps=con.prepareStatement(  
		    "select * from world.patient where pemail=? and psw=?");  
		  
		ps.setString(1,com.getemail());  
		ps.setString(2, com.getpsw()); 
	
		              
		ResultSet rs=ps.executeQuery();  
		status=rs.next(); 
		System.out.println(status);
		
       
        
       
       
		              
		}
		catch(Exception e){}  
		  
		return status;  
		  
		}
}



