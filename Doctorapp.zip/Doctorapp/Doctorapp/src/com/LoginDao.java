package com;



import java.sql.*;

public class LoginDao {
	public static boolean validate(String email,String psw) {        
        boolean status = false;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        String url = "jdbc:mysql://127.0.0.1:3306/";
        String dbName = "world";
        
        String userName = "root";
        String password = "Jaigurudev@1976";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager
                    .getConnection(url + dbName, userName, password);

            pst = conn.prepareStatement("select * from doctor where email=? and psw=? ");
            pst.setString(1, email);
            
            pst.setString(2, psw);
           
         
            rs = pst.executeQuery();
            status = rs.next();
           

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pst != null) {
                try {
                    pst.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return status;
    }
}
