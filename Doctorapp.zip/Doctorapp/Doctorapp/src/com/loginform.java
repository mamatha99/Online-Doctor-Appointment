package com;
 
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.DB; 
import java.sql.Connection;

public class loginform {
	public static boolean validate(logincom com)
	{  
		boolean status=true;  
		try
		{  
		Connection con=DB.con(); 
		              
		PreparedStatement ps=con.prepareStatement(  
		    "select * from world.doctor where email=? and psw=?");  
		  
		ps.setString(1,com.getemail());  
		ps.setString(2, com.getpsw());  
		              
		ResultSet rs=ps.executeQuery();  
		status=rs.next(); 
		System.out.println(status);
		
		              
		}
		catch(Exception e){}  
		  
		return status;  
		  
		}
}



