package com;

import java.sql.Connection;
import java.sql.DriverManager;

public class admindashboard {
	final static String DB_URL = "jdbc:mysql://localhost:3306/doctor";
	final static String USER = "root";
	final static String PASS = "mahimanu@123";
	public static Connection con()
	{
		Connection con;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			return con;
			}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	
	


}
